package com.csm.collection;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class SetExample {

	public static void main(String[] args) 
	{
		Set<String> s = new HashSet<>();
		s.add("B");
		s.add("C");
		s.add("A");
		
		
		Set<Integer> s1 = new HashSet<>();
		s1.add(3);
		s1.add(2);
		s1.add(1);
		
		Set<Float> s2 = new HashSet<>();
		s2.add(50.0F);
		s2.add(80.8F);
		s2.add(70.0F);
		
		Set<Object> s3 = new HashSet<>();
		s3.addAll(s);
		s3.addAll(s1);
		s3.addAll(s2);
		
		Iterator<Object> i = s3.iterator();
		while(i.hasNext())
		{
			System.out.println(i.next());
		}
	}

}

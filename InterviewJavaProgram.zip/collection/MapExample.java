package com.csm.collection;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class MapExample 
{
	public static void main(String[] args) 
	{
		Map<Integer, String> m = new HashMap<>();
		m.put(4, "D");
		m.put(2, "B");
		m.put(3, "C");
		m.put(1, "A");
		
		System.out.println(m.get(3));
		Map<Integer, String> m1 = new HashMap<>();
		m1.put(6, "F");
		m1.put(6, "F");
		m1.put(5, "E");
		m1.put(7, null);
		
		Map<Integer, String> m2 = new HashMap<>();
		m2.putAll(m);
		m2.putAll(m1);
		
		System.out.println(m2);
		
		//Set<Entry<Integer, String>> entrySet = m2.entrySet();
		
//		for(Entry<Integer, String> i:m2.entrySet())
//		{
//			Integer key = i.getKey();
//			String value = i.getValue();
//			
//			System.out.println(key+" : "+value);
//		}
		
		for(Integer i:m2.keySet())
		{
			String string = m2.get(i);
			
			System.out.println(i+" : "+string);
		}
	}

}

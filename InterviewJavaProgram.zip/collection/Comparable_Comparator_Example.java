package com.csm.collection;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

class User implements  Comparable<User>
{
	int id;
	String name;

	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}



	@Override
	public String toString() {
		return "User [id=" + id + ", name=" + name + "]";
	}


	@Override
	public int compareTo(User o) 
	{
		//return this.getName().compareTo(o.getName());
		return Integer.compare(this.getId(),o.getId());
	}
	
}
class ComparatorExample implements Comparator<User>
{

	@Override
	public int compare(User o1, User o2) 
	{
		return o1.getName().compareTo(o2.getName());
	}
	
}

public class Comparable_Comparator_Example 
{
    public static void main(String[] args) 
    {
       User user = new User();
       user.setId(3);
       user.setName("B");
       
       User user1 = new User();
       user1.setId(1);
       user1.setName("C");
       
       User user2 = new User();
       user2.setId(2);
       user2.setName("A");
       
       ComparatorExample c = new ComparatorExample();
       List<User> l = new ArrayList<>();
       l.add(user);
       l.add(user1);
       l.add(user2);
       
       System.out.println("Without Sorting : ");
       System.out.println(l);
      
       Collections.sort(l,c);
       System.out.println("By Using Comparator: ");
       System.out.println(l);
       
       
       System.out.println("By Using Comparable: ");
       Collections.sort(l);
       System.out.println(l);
       
    }
}

package com.csm.string;

public class StringCondition 
{
	public static void main(String[] args) 
	{
		String s="Shadab";
		String s1=null;
		
		System.out.println("Shadab".equals(s) || s1 == null);		//-> || (logical OR)

		System.out.println(s.equals("Shadab") | s1.equals(null));	//-> | (bitwise OR) 

		
	}
	

}
